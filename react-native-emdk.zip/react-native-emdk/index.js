import BarcodeScanner from './lib/BarcodeScanner';
export default BarcodeScanner;

import { BarcodeScannerEvent } from './lib/BarcodeScannerEvent';
export { BarcodeScannerEvent };