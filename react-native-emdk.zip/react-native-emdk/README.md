# react-native-emdk
Add to AndroidManifest.xml

```
<uses-permission android:name="com.symbol.emdk.permission.EMDK" />

<uses-library android:name="com.symbol.emdk" android:required="false" />
```
